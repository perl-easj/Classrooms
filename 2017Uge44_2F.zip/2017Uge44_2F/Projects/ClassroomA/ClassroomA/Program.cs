﻿using System;

namespace ClassroomA
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting demo of Entity Framework...");


            using (var db = new CarRetailDBContext())
            {
                Console.WriteLine("All Car records in database:");
                foreach (Car c in db.Cars)
                {
                    Console.WriteLine(c);
                }
                Console.WriteLine();
            }

            Console.WriteLine("Done, press any key to close application...");
            Console.ReadKey();
        }
    }
}
