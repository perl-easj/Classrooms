﻿using System;
using System.Collections.Generic;
using WebServiceServer;

namespace WebServiceClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting demo of Web Service...");

            WebAPIWrapper<Car> _webApiCar = new WebAPIWrapper<Car>("http://classroombperleasj.azurewebsites.net/", "Cars");

            List<Car> cars = _webApiCar.Load().Result;

            foreach (Car c in cars)
            {
                Console.WriteLine(c);
            }

            Console.WriteLine("Done, press any key to close application...");
            Console.ReadKey();
        }
    }
}
