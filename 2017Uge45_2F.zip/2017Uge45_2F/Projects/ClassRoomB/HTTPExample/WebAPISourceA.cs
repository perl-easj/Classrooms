﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace HTTPExample
{
    public class WebAPISourceA<T>
    {
        #region Instance fields
        private string _serverURL;
        private string _apiID;
        private HttpClientHandler _httpClientHandler;
        private HttpClient _httpClient;
        #endregion

        #region Constructor
        public WebAPISourceA(string serverURL, string apiID)
        {
            _serverURL = serverURL;
            _apiID = apiID;

            _httpClientHandler = new HttpClientHandler();
            _httpClientHandler.UseDefaultCredentials = true;

            _httpClient = new HttpClient(_httpClientHandler);
            _httpClient.BaseAddress = new Uri(_serverURL);
        }
        #endregion

        #region Implementation of Domain-oriented CRUD/Load methods
        public async Task<List<T>> Load()
        {
            // Prepare HTTP client for method invocation
            _httpClient.DefaultRequestHeaders.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            // Invoke GetAsync - the method will at some point 
            // return an HttpResponseMessage 
            HttpResponseMessage response = await _httpClient.GetAsync($"api/{_apiID}").ConfigureAwait(false);

            // Throw exception if the invocation was unsuccessful
            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"{(int)response.StatusCode} - {response.ReasonPhrase}");
            }

            // Return the list of objects
            return await response.Content.ReadAsAsync<List<T>>();
        }

        public async Task Create(T obj)
        {
            // Prepare HTTP client for method invocation
            _httpClient.DefaultRequestHeaders.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            // Invoke the method - the method will at some point 
            // return an HttpResponseMessage 
            HttpResponseMessage response = await _httpClient.PostAsJsonAsync($"api/{_apiID}", obj).ConfigureAwait(false);

            // StringContent strContent = new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
            // HttpResponseMessage response2 = await _httpClient.PostAsync($"api/{_apiID}", strContent);

            // Throw exception if the invocation was unsuccessful
            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"{(int)response.StatusCode} - {response.ReasonPhrase}");
            }
        }

        public async Task<T> Read(int key)
        {
            // Prepare HTTP client for method invocation
            _httpClient.DefaultRequestHeaders.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            // Invoke GetAsync - the method will at some point 
            // return an HttpResponseMessage 
            HttpResponseMessage response = await _httpClient.GetAsync($"api/{_apiID}/{key}").ConfigureAwait(false);

            // Throw exception if the invocation was unsuccessful
            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"{(int)response.StatusCode} - {response.ReasonPhrase}");
            }

            // Return single object
            return await response.Content.ReadAsAsync<T>();
        }

        public async Task Update(int key, T obj)
        {
            // Prepare HTTP client for method invocation
            _httpClient.DefaultRequestHeaders.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            // Invoke the method - the method will at some point 
            // return an HttpResponseMessage 
            HttpResponseMessage response = await _httpClient.PutAsJsonAsync($"api/{_apiID}/{key}", obj).ConfigureAwait(false);

            // Throw exception if the invocation was unsuccessful
            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"{(int)response.StatusCode} - {response.ReasonPhrase}");
            }
        }

        public async Task Delete(int key)
        {
            // Prepare HTTP client for method invocation
            _httpClient.DefaultRequestHeaders.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            // Invoke the method - the method will at some point 
            // return an HttpResponseMessage 
            HttpResponseMessage response = await _httpClient.DeleteAsync($"api/{_apiID}/{key}").ConfigureAwait(false);

            // Throw exception if the invocation was unsuccessful
            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"{(int)response.StatusCode} - {response.ReasonPhrase}");
            }
        }
        #endregion
    }
}