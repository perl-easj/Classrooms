﻿using System;
using System.Collections.Generic;
using WebServiceServer;

namespace WebServiceClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting demo of Web Service...");

            WebAPIWrapper<Car> _webApiCar = new WebAPIWrapper<Car>("http://localhost:1143/", "Cars");

            List<Car> cars = _webApiCar.Load().Result;

            foreach (Car c in cars)
            {
                Console.WriteLine(c);
            }

            Console.WriteLine("Provoking exception...");
            _webApiCar.Delete(88).Wait();

            Console.WriteLine("Done, press any key to close application...");
            Console.ReadKey();
        }
    }
}
