﻿using System.Collections.Generic;

namespace ClassroomA
{
    public class CollectionWrapper<T, V> where T : ICollection<V>
    {
        private T _collection;

        public int Count
        {
            get { return _collection.Count; }
        }
    }
}