﻿using System;

// ReSharper disable SuggestVarOrType_BuiltInTypes
// ReSharper disable RedundantAssignment
#pragma warning disable 219
#pragma warning disable 168

namespace Sandbox
{
    public class InsertCodeHere
    {
        public void MyCode()
        {
            // The FIRST line of code should be BELOW this line

            #region Variable med primitive typer

            int age = 50;

            double height = 1.86;

            string name = "Per Laursen";

            bool isMarried = false;

            #endregion

             
            #region Aritmetik (int og double)

            age = age - 8;
            int monthsInYear = 12;
            int ageInMonths = age * monthsInYear;

            double incomeTax = 8.5;
            double housingTax = 2.3;
            double zoneTax = 4.8;

            double tax = incomeTax + housingTax + 0.5 * zoneTax;

            #endregion


            #region Heltalsdivision og modulo

            ageInMonths = 50 * 12 + 2; // = 602

            int ageInYears = ageInMonths / 12; // NB!

            int months = ageInMonths % 12; // Modulo (rest ved heltalsdivision) 

            #endregion


            #region Type-konvertering

            int price = 30;
            double priceWithTax = price * 1.25;

            string fullName = "Per" + " " + "Laursen";
            string message = "The price (including tax) is " + priceWithTax + " kr.";

            #endregion


            #region Console.WriteLine og format-string

            Console.WriteLine(message);

            string newerMessage = $"The price (including tax) is {priceWithTax}  kr.";

            Console.WriteLine($"{name} The price (including tax) is {priceWithTax}  kr.");

            #endregion


            #region Logik

            int a = 12;
            int b = 17;

            bool areEqual = (a == b);
            bool bLarger = (b > a);

            int ageOfCustomer = 16;
            bool isAdult = (ageOfCustomer >= 18);

            bool isTeenager = (ageOfCustomer > 12) && (ageOfCustomer < 20);

            bool canGetDiscount = (ageOfCustomer < 11) || (ageOfCustomer >= 65);

            bool mustPayFullPrice = !canGetDiscount;




            double d = 3.0;
            double e = Math.Sqrt(d) * Math.Sqrt(d);
            double zero = e - d;
            Console.WriteLine($"zero = {zero}");

            bool is37Prime = IsPrime(37);

            bool isZero = (zero == 0.0);
            Console.WriteLine($"isZero = {isZero}");

            bool isCloseEnoughToZero = (Math.Abs(zero) < 0.0000001 );
            Console.WriteLine($"isCloseEnoughToZero = {isCloseEnoughToZero}");

            #endregion


            #region Funktioner

            for (int i = 1; i < 100; i++)
            {
                // Logic for determining if a number is a
                // prime number is defined in a separate method.
                if (IsPrime(i))
                {
                    Console.WriteLine($"{i} is prime");
                }
            }

            double netPriceA = 120;
            double shipping = 29;
            int taxPercentage = 25;

            double totalPriceA = CalculateTotalPrice(netPriceA);

            double netPriceB = 200;
            double totalPriceB = CalculateTotalPrice(netPriceB);


            double netPriceC = 200;
            double totalPriceC = CalculateTotalPrice(netPriceC); 

            #endregion

            // The LAST line of code should be ABOVE this line
        }

        public double CalculateTotalPrice(double netPrice)
        {
            double totalPrice = ((netPrice + 29) * (100 + 25) / 100);
            return totalPrice;
        }

        public bool IsPrime(int value)
        {
            if (value < 4) return true;

            int limit = (int)Math.Sqrt(value) + 1;
            for (int i = 2; i < limit; i++)
            {
                if (value % i == 0) return false;
            }

            return true;
        }
    }
}