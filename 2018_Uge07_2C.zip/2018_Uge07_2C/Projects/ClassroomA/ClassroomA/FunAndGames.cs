﻿using System;

namespace ClassroomA
{
    public class FunAndGames
    {
        public static void WooHoo(double blabla)
        {
            Console.WriteLine("I dont care about any stinkin' temperatures!");
        }
    }
}