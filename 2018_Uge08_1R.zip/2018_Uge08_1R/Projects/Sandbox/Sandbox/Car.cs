﻿namespace Sandbox
{
    /// <summary>
    /// This class contains a very simple model for
    /// a Car, intended to use in a Car Retail system.
    /// </summary>
    public class Car
    {
        // Instance fields
        private string _licensePlate;
        private int _price;

        /// <summary>
        /// Constructor takes a license plate,
        /// and a price. The price may later
        /// be updated.
        /// </summary>
        public Car(string licensePlate, int price)
        {
            _licensePlate = licensePlate;
            _price = price;
        }

        /// <summary>
        /// The license plate of the car.
        /// Cannot be changed after creation.
        /// </summary>
        public string LicensePlate
        {
            get { return _licensePlate; }
        }

        /// <summary>
        /// The price of the car. Can be 
        /// updated after creation.
        /// </summary>
        public int Price
        {
            get { return _price; }
            set
            {
                if (value > 0)
                {
                    _price = value;
                }               
            }
        }

        /// <summary>
        /// Reduce the price of the car by
        /// a specified percentage
        /// </summary>
        /// <param name="percent">
        /// Percentage by which to reduce price.
        /// </param>
        public void ReducePrice(int percent)
        {
                Price = (Price * (100 - percent))/100;
        }


    }
}