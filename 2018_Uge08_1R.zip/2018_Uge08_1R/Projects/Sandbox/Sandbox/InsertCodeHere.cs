﻿using System;

// ReSharper disable SuggestVarOrType_BuiltInTypes
// ReSharper disable RedundantAssignment
#pragma warning disable 219
#pragma warning disable 168

namespace Sandbox
{
    public class InsertCodeHere
    {
        public void MyCode()
        {
            // The FIRST line of code should be BELOW this line


            Car c = new Car("AB 23 435", 80000);
            Car c2 = new Car("BH 33 456", 50000);
            Console.WriteLine(c.Price);

            Console.WriteLine(c.Price);


            Console.WriteLine(c.Price);


            //Console.WriteLine(c.Price);
            //c.ReducePrice(20);
            //Console.WriteLine(c.Price);



            // The LAST line of code should be ABOVE this line

            int v = SWCMath.Add(2, 5);
        }

        public void DoubleUp(int v)
        {
            v = v * 2;
        }

        public void DoublePrice(Car aCar)
        {
            aCar.Price = aCar.Price * 2;
        }
    }
}