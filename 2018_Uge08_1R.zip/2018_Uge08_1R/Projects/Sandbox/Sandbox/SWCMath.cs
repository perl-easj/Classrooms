﻿namespace Sandbox
{
    public class SWCMath
    {
        private static int _test;

        static SWCMath()
        {
            _test = 0;
        }

        public SWCMath()
        {
            _test++;
        }

        public static int Test
        {
            get { return _test; }
        }

        public static int Add(int a, int b)
        {
            return a + b;
        }

        public static int Subtract(int a, int b)
        {
            return a - b;
        }
    }
}