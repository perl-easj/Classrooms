﻿namespace Sandbox
{
    public class Stock
    {
        
    }
}