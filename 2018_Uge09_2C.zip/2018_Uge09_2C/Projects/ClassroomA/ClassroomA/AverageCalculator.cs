﻿using System.Collections.Generic;
using System.Threading.Tasks;
// ReSharper disable RedundantAssignment
// ReSharper disable ForCanBeConvertedToForeach

namespace ClassroomA
{
    public class AverageCalculator
    {
        public long Average(List<int> numbers)
        {
            return Average(numbers, 0, numbers.Count);
        }

        public long Average(List<int> numbers, int from, int to)
        {
            long sum = 0;
            for (int i = from; i < to; i++)
            {
                sum = sum + numbers[i];
            }
            return sum / (to - from);
        }

        public long AverageMultiTasks(List<int> numbers)
        {
            // Setup part-variables
            long sumPartA = 0;
            long sumPartB = 0;
            long sumPartC = 0;
            long sumPartD = 0;

            Task taskA = new Task(() => { sumPartA = Average(numbers, 0, numbers.Count / 4); });
            Task taskB = new Task(() => { sumPartB = Average(numbers, numbers.Count / 4, numbers.Count / 2); });
            Task taskC = new Task(() => { sumPartC = Average(numbers, numbers.Count / 2, 3 * numbers.Count / 4); });
            Task taskD = new Task(() => { sumPartD = Average(numbers, 3 * numbers.Count / 4, numbers.Count); });

            taskA.Start();
            taskB.Start();
            taskC.Start();
            taskD.Start();

            Task.WaitAll(taskA, taskB, taskC, taskD);
            
            return (sumPartA + sumPartB + sumPartC + sumPartD) / 4;
        }
    }
}