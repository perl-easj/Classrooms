﻿namespace ClassroomB
{
    public class Actor
    {
        private string _name;
        private int _yearOfBirth;

        public Actor(string name, int yearOfBirth)
        {
            _name = name;
            _yearOfBirth = yearOfBirth;
        }

        public string Name
        {
            get { return _name; }
        }

        public int YearOfBirth
        {
            get { return _yearOfBirth; }
        }

        public override string ToString()
        {
            return $"{Name}, born {YearOfBirth}";
        }
    }
}