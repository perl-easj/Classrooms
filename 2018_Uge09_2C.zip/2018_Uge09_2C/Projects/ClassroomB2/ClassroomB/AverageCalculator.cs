﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace ClassroomB
{
    public class AverageCalculator
    {
        public long AverageWithCancel(List<int> numbers, CancellationToken token)
        {
            return AverageWithCancel(numbers, 0, numbers.Count, token);
        }

        public long AverageWithCancel(List<int> numbers, int from, int to, CancellationToken token)
        {
            long sum = 0;

            for (int j = 0; j < 100 && !token.IsCancellationRequested; j++) // artificial delay
            {
                sum = 0;

                for (int i = from; i < to && !token.IsCancellationRequested; i++)
                {
                    sum = sum + numbers[i];
                } 
            }

            if (token.IsCancellationRequested)
            {
                return -1;
            }

            return sum / (to - from);
        }

        public long AverageAsTask(List<int> numbers, CancellationToken token)
        {
            Task<long> taskA = new Task<long>(() => AverageWithCancel(numbers, 0, numbers.Count, token), token);
            taskA.Start();
            return taskA.Result;
        }
    }
}