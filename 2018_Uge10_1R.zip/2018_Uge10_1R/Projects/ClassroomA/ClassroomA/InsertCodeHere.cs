﻿using System;

namespace ClassroomA
{
    public class InsertCodeHere
    {
        public void MyCode()
        {
            int height = 182;
            bool male = true;
            int age = 19;


            if (age < 20)
            {
                Console.WriteLine("You are too young for the Police, sorry...");
            }
            else if (height < 164 || (height < 172 && male))
            {
                Console.WriteLine("You are too short for the Police, sorry...");
            }
            else
            {
                Console.WriteLine("Welcome to the Police... guns are overhere!");
            }
        }

        public int ChildSubsidy(int noOfChildren)
        {
            switch (noOfChildren)
            {
                case 0:
                    return 0;
                case 1:
                    return 1200;
                case 2:
                    return 2200;
                default:
                    return 3000;
            }
        }
    }
}