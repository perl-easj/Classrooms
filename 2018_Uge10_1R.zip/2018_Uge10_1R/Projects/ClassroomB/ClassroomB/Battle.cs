﻿namespace ClassroomB
{
    public class Battle
    {
        private Army _armyA;
        private Army _armyB;

        public Battle(Army armyA, Army armyB)
        {
            _armyA = armyA;
            _armyB = armyB;
        }

        public void DoBattle()
        {
            
        }
    }
}