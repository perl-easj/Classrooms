﻿namespace ClassroomC
{
    public class DiceGame
    {
        private Die _die1;
        private Die _die2;

        // ...og så videre
    }
}