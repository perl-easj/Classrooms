﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassroomA
{
    public class PrimeCalc
    {
        private List<int> _primes;
        private List<int> _notPrimes;

        private object _lockPrimes;
        private object _lockNotPrimes;

        public PrimeCalc()
        {
            _primes = new List<int>();
            _notPrimes = new List<int>();
            _lockPrimes = new object();
            _lockNotPrimes = new object();
        }

        public void FindPrimes(int upper)
        {
            lock (_lockPrimes)
            {
                _primes.Clear();
            }

            lock (_lockNotPrimes)
            {
                _notPrimes.Clear();
            }


            // FindPrimesInInterval(1, upper);

            #region with Tasks
            int middle = upper / 2;
            Task t1 = Task.Run(() => FindPrimesInInterval(1, middle));
            Task t2 = Task.Run(() => FindPrimesInInterval(middle + 1, upper));
            t1.Wait();
            t2.Wait();
            #endregion

            Console.WriteLine($"Found {_primes.Count} primes in [1; {upper}]");
            Console.WriteLine($"Found {_notPrimes.Count} non-primes in [1; {upper}]");
        }

        private void FindPrimesInInterval(int lower, int upper)
        {
            for (int i = lower; i <= upper; i++)
            {
                if (IsPrime(i))
                {
                    lock (_lockPrimes)
                    {
                        _primes.Add(i);
                    }
                }
                else
                {
                    lock (_lockNotPrimes)
                    {
                        _notPrimes.Add(i);
                    }
                }
            }
        }

        private bool IsPrime(int number)
        {
            if (number < 4) { return true; }

            int limit = Convert.ToInt32(Math.Sqrt(number));
            bool isPrime = true;

            for (int i = 2; i <= limit && isPrime; i++)
            {
                isPrime = number % i != 0;
            }

            return isPrime;
        }
    }
}