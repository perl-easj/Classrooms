﻿using System;

namespace ClassroomA
{
    class Program
    {
        static void Main(string[] args)
        {
            PrimeCalcBag pCalc = new PrimeCalcBag();
            pCalc.FindPrimes(1000000);

            Console.WriteLine();
            Console.WriteLine("(in Main at ReadKey...)");

            Console.ReadKey();
        }
    }
}
