﻿using System;

namespace ClassroomA
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var db = new CarRetailDBContext())
            {
                #region Print all Car objects
                Console.WriteLine("All records in Car table:");
                foreach (Car c in db.Cars)
                {
                    Console.WriteLine(c);
                }
                Console.WriteLine();
                #endregion

                #region Create new Car objects
                Car c1 = new Car
                {
                    Id = 101,
                    LicensePlate = "XY 12 345",
                    Brand = "Mercedes",
                    Model = "E 230",
                    Price = 68000,
                    Year = 2009,
                    EngineSize = 2300,
                    HorsePower = 180,
                    Seats = 5,
                    ImageKey = 0
                };

                Car c2 = new Car
                {
                    Id = 102,
                    LicensePlate = "YZ 23 456",
                    Brand = "BMW",
                    Model = "318i",
                    Price = 140000,
                    Year = 2012,
                    EngineSize = 1800,
                    HorsePower = 145,
                    Seats = 4,
                    ImageKey = 0
                };
                #endregion

                #region Add Car objects to database
                //db.Cars.Add(c1);
                //db.Cars.Add(c2);
                //db.SaveChanges(); 
                #endregion

                #region Remove Car objects from database
                //Car c101 = db.Cars.Find(101);
                //if (c101 != null) { db.Cars.Remove(c101); }
                //Car c102 = db.Cars.Find(102);
                //if (c102 != null) { db.Cars.Remove(c102); }
                //db.SaveChanges(); 
                #endregion
            }

            Console.WriteLine("Press any key to close application");
            Console.ReadKey();
        }
    }
}
