namespace ClassroomB
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class CarRetailDBContext : DbContext
    {
        public CarRetailDBContext()
            : base("name=CarRetailDBContext")
        {
        }

        public virtual DbSet<Car> Cars { get; set; }
        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<Sale> Sales { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Car>()
                .Property(e => e.LicensePlate)
                .IsFixedLength();

            modelBuilder.Entity<Car>()
                .Property(e => e.Brand)
                .IsFixedLength();

            modelBuilder.Entity<Car>()
                .Property(e => e.Model)
                .IsFixedLength();

            modelBuilder.Entity<Customer>()
                .Property(e => e.FullName)
                .IsFixedLength();

            modelBuilder.Entity<Customer>()
                .Property(e => e.Address)
                .IsFixedLength();

            modelBuilder.Entity<Customer>()
                .Property(e => e.City)
                .IsFixedLength();

            modelBuilder.Entity<Customer>()
                .Property(e => e.Email)
                .IsFixedLength();

            modelBuilder.Entity<Customer>()
                .Property(e => e.Phone)
                .IsFixedLength();

            modelBuilder.Entity<Employee>()
                .Property(e => e.FullName)
                .IsFixedLength();

            modelBuilder.Entity<Employee>()
                .Property(e => e.Title)
                .IsFixedLength();

            modelBuilder.Entity<Employee>()
                .Property(e => e.Phone)
                .IsFixedLength();

            modelBuilder.Entity<Employee>()
                .Property(e => e.Email)
                .IsFixedLength();
        }
    }
}
