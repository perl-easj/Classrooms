﻿using System;

namespace ClassroomB
{
    class Program
    {
        static void Main(string[] args)
        {
            // DBAccessWithEF();
            DBAccessWithWS();

            Console.WriteLine("Press any key to close application");
            Console.ReadKey();
        }

        static async void DBAccessWithWS()
        {
            const string serverURL = "https://demoaserver20180315.azurewebsites.net";
            const string apiPrefix = "api";

            const string carURI = "Cars";
            const string customerURI = "Customers";
            const string employeeURI = "Employees";
            const string saleURI = "Sales";
            
            WebAPIAsync<Car> carWebApi = new WebAPIAsync<Car>(serverURL, apiPrefix, carURI);
            WebAPIAsync<Customer> customerWebApi = new WebAPIAsync<Customer>(serverURL, apiPrefix, customerURI);
            WebAPIAsync<Employee> employeeWebApi = new WebAPIAsync<Employee>(serverURL, apiPrefix, employeeURI);
            WebAPIAsync<Sale> saleWebApi = new WebAPIAsync<Sale>(serverURL, apiPrefix, saleURI);

            WebAPITest<Car> carWebAPITester = new WebAPITest<Car>(carWebApi, "Car");
            WebAPITest<Customer> customerWebAPITester = new WebAPITest<Customer>(customerWebApi, "Customer");
            WebAPITest<Employee> employeeWebAPITester = new WebAPITest<Employee>(employeeWebApi, "Employee");
            WebAPITest<Sale> saleWebAPITester = new WebAPITest<Sale>(saleWebApi, "Sale");

            await carWebAPITester.RunAPITestLoad();
            await customerWebAPITester.RunAPITestLoad();
            await employeeWebAPITester.RunAPITestLoad();
            await saleWebAPITester.RunAPITestLoad();
        }

        static void DBAccessWithEF()
        {
            using (var db = new CarRetailDBContext())
            {
                #region Print all Car objects
                Console.WriteLine("All records in Car table:");
                foreach (Car c in db.Cars)
                {
                    Console.WriteLine(c);
                }
                Console.WriteLine();
                #endregion

                #region Create new Car objects
                Car c1 = new Car
                {
                    Id = 101,
                    LicensePlate = "XY 12 345",
                    Brand = "Mercedes",
                    Model = "E 230",
                    Price = 68000,
                    Year = 2009,
                    EngineSize = 2300,
                    HorsePower = 180,
                    Seats = 5,
                    ImageKey = 0
                };

                Car c2 = new Car
                {
                    Id = 102,
                    LicensePlate = "YZ 23 456",
                    Brand = "BMW",
                    Model = "318i",
                    Price = 140000,
                    Year = 2012,
                    EngineSize = 1800,
                    HorsePower = 145,
                    Seats = 4,
                    ImageKey = 0
                };
                #endregion

                #region Add Car objects to database
                Car c101 = db.Cars.Find(101);
                if (c101 != null) { db.Cars.Remove(c101); }
                Car c102 = db.Cars.Find(102);
                if (c102 != null) { db.Cars.Remove(c102); }
                db.SaveChanges();


                db.Cars.Add(c1);
                db.Cars.Add(c2);
                db.SaveChanges();
                #endregion

                #region Remove Car objects from database

                #endregion
            }
        }
    }
}
