﻿namespace ClassroomA
{
    public enum FruitType
    {
        Apple,​
        Banana,​
        Cherry,​
        Kiwi,​
        Pear
    }
}