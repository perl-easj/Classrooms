﻿using System;
using System.Collections.Generic;

namespace ClassroomA
{
    public class InsertCodeHere
    {
        public void MyCode()
        {
            #region Create StockDetails objects
            StockDetails sdA = new StockDetails("NOVO", "Novo Nordisk", 1, 4.85);
            StockDetails sdB = new StockDetails("DABK", "Danske Bank", 10, 9.5);
            StockDetails sdC = new StockDetails("VEST", "Vestas", 1, 12.8);
            StockDetails sdD = new StockDetails("TRYG", "Tryg Forsikring", 2, 6.35);
            #endregion

            #region Create Dictionary and add objects
            Dictionary<string, StockDetails> stocks = new Dictionary<string, StockDetails>();
            stocks.Add(sdA.ID, sdA);
            stocks.Add(sdB.ID, sdB);
            stocks[sdC.ID] = sdC;
            stocks[sdD.ID] = sdD;
            #endregion

            #region Lookup objects by ID
            if (stocks.ContainsKey("NOVO"))
            {
                Console.WriteLine(stocks["NOVO"]);
            }
            else
            {
                Console.WriteLine("Stock with ID NOVO not found...");
            }

            if (stocks.ContainsKey("NOVA"))
            {
                Console.WriteLine(stocks["NOVA"]);
            }
            else
            {
                Console.WriteLine("Stock with ID NOVA not found...");
            }
            #endregion

            #region Iterate over keys and values
            Console.WriteLine();
            foreach (var key in stocks.Keys)
            {
                Console.WriteLine($"Key: {key}");
            }

            Console.WriteLine();
            foreach (var val in stocks.Values)
            {
                Console.WriteLine($"Value: {val}");
            }

            Console.WriteLine();
            foreach (var kvp in stocks)
            {
                Console.WriteLine($"Key: {kvp.Key}   Value: {kvp.Value}");
            }
            #endregion

            #region Remove and re-iterate
            stocks.Remove("DABK");
            stocks.Remove("NOVA");

            if (stocks.ContainsKey("NOVA"))
            {
                Console.WriteLine(stocks["NOVA"]);
            }

            Console.WriteLine();
            foreach (var val in stocks.Values)
            {
                Console.WriteLine($"Value: {val}");
            } 
            #endregion

            string fruitTypeId = "Apple";

            FruitType fruitExample = FruitType.Apple;
        }
    }
}