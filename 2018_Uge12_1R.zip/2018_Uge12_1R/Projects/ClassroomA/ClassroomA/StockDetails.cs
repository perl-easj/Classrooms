﻿namespace ClassroomA
{
    public class StockDetails
    {
        #region Instance fields
        private string _id;
        private string _fullName;
        private int _nominalValue;
        private double _dividend;
        #endregion

        #region Constructor
        public StockDetails(string id, string fullName, int nominalValue, double dividend)
        {
            _id = id;
            _fullName = fullName;
            _nominalValue = nominalValue;
            _dividend = dividend;
        }
        #endregion

        #region Properties
        public string ID
        {
            get { return _id; }
        }

        public string FullName
        {
            get { return _fullName; }
        }

        public int NominalValue
        {
            get { return _nominalValue; }
        }

        public double Dividend
        {
            get { return _dividend; }
            set { _dividend = value; }
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            return $"{ID}: {FullName} has nominal value {NominalValue} kr, pays {Dividend:F2} kr. in dividend";
        } 
        #endregion
    }
}