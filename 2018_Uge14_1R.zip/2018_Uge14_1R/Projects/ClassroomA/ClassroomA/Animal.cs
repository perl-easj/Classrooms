﻿using System;

namespace ClassroomA
{
    public class Animal
    {
        private int _age;

        public Animal(int age)
        {
            _age = age;
        }

        public int Age
        {
            get { return _age; }
        }

        public virtual void Sound()
        {
            Console.Write("Says: ");
        }
    }
}