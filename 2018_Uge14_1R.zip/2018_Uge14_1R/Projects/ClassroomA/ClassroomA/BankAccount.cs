﻿namespace ClassroomA
{
    public class BankAccount
    {
        private string _ownerName;
        private double _balance;
        private double _interestRate;

        public BankAccount(string ownerName, double interestRate)
        {
            _balance = 0;
            _ownerName = ownerName;
            _interestRate = interestRate;
        }

        public double Balance
        {
            get { return _balance; }
        }

        public string OwnerName
        {
            get { return _ownerName; }
        }

        public double InterestRate
        {
            get { return _interestRate; }
            set { _interestRate = value; }
        }

        public void Deposit(double amount)
        {
            _balance = _balance + amount;
        }

        public void Withdraw(double amount)
        {
            _balance = _balance - amount;
        }

    }
}