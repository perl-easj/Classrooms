﻿using System;

namespace ClassroomA
{
    public class Duck : Animal
    {
        public override void Sound()
        {
            Console.WriteLine("Quack!");
        }

        public void Eat()
        {
            Console.WriteLine("Nom nom...");
        }

        public Duck(int age) : base(age)
        {
        }
    }
}