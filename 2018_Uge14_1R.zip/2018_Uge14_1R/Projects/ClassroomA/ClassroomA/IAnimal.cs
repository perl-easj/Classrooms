﻿namespace ClassroomA
{
    public interface IAnimal
    {
        void Sound();
        void Eat();
        bool Sleeping { get; }
    }
}