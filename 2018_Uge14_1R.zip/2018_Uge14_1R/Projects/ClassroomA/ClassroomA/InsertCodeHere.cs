﻿// ReSharper disable UnusedVariable

using System.Collections.Generic;

namespace ClassroomA
{
    public class InsertCodeHere
    {
        public void MyCode()
        {
            #region Inheritance Demo

            //SavingsAccount savingsAcc =
            //    new SavingsAccount("Per", 0.5, 6);

            //ShareholderAccount shareHolderAcc =
            //    new ShareholderAccount("Per", 1.5, 1.02);

            //savingsAcc.Deposit(5000);
            //shareHolderAcc.Deposit(8000);

            //savingsAcc.PrintInformation();
            //shareHolderAcc.PrintInformation();

            #endregion

            #region Polymorphic demo

            //Animal a1 = new Animal(12);
            //a1.Sound();

            Dog d1 = new Dog(7, false);
            Cat c1 = new Cat(4, 45);
            Dog d2 = new Dog(5, true);
            Duck du1 = new Duck(2);

            List<Animal> pets = new List<Animal>();

            pets.Add(d1);
            pets.Add(c1);
            pets.Add(d2);
            pets.Add(du1);

            foreach (Animal a in pets)
            {
                a.Sound();
            }


            //Dog d = new Dog(5, true);
            //d.Sound();

            //Animal a2 = new Dog(7, true);
            //a2.Sound();

            #endregion
        }
    }
}