﻿using System;

namespace ClassroomA
{
    public class SavingsAccount : BankAccount
    {
        #region Instance fields
        private int _bindingPeriod;
        #endregion

        #region Constructor
        public SavingsAccount(string ownerName, double interestRate, int bindingPeriod)
            : base(ownerName, interestRate)
        {
            _bindingPeriod = bindingPeriod;
        }
        #endregion

        #region Properties
        public int BindingPeriod
        {
            get { return _bindingPeriod; }
            set { _bindingPeriod = value; }
        }
        #endregion

        #region Methods
        public void PrintInformation()
        {
            Console.Write($"Savings Account" +
                          $", owned by {OwnerName}" +
                          $", balance is {Balance}" +
                          $", interest rate {InterestRate:F2}" +
                          $", binding {BindingPeriod} months");
            Console.WriteLine();
        } 
        #endregion
    }
}