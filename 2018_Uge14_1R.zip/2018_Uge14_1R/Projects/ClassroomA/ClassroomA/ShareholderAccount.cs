﻿using System;

namespace ClassroomA
{
    public class ShareholderAccount : BankAccount
    {
        #region Instance fields
        private double _bonusFactor;
        #endregion

        #region Constructor
        public ShareholderAccount(string ownerName,double interestRate, double bonusFactor) 
            : base(ownerName, interestRate)
        {
            _bonusFactor = bonusFactor;
        }
        #endregion

        #region Properties
        public double BonusFactor
        {
            get { return _bonusFactor; }
            set { _bonusFactor = value; }
        }
        #endregion

        #region Methods
        public void PrintInformation()
        {
            Console.Write($"Shareholder Account" +
                          $", owned by {OwnerName}" +
                          $", balance is {Balance}" +
                          $", interest rate {InterestRate:F2}" +
                          $", bonus factor {BonusFactor:F2}");
            Console.WriteLine();
        } 
        #endregion
    }
}