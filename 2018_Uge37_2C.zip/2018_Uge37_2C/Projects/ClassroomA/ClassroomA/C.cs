﻿namespace ClassroomA
{
    public class C<T> : IGet<T>, ISet<T>
    {
        private T _t;

        public T Get()
        {
            return _t;
        }

        public void Set(T t)
        {
            _t = t;
        }
    }
}