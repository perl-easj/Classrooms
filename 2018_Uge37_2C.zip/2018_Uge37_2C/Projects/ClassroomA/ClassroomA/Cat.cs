﻿namespace ClassroomA
{
    public class Cat : Animal
    {
        public bool _isNeutered;

        public Cat(string name, int weight, bool isNeutered) 
            : base(name, weight)
        {
            _isNeutered = isNeutered;
        }

        public bool IsNeutered
        {
            get { return _isNeutered; }
            set { _isNeutered = value; }
        }

        public override string ToString()
        {
            string neuteredStr = _isNeutered ? "neutered " : "";
            return $"A {neuteredStr}cat named {Name}, {Weight} kg";
        }
    }
}