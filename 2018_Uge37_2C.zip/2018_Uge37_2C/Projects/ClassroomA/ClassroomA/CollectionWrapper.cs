﻿using System.Collections.Generic;

namespace ClassroomA
{
    public class CollectionWrapper<T, V> 
        where T : ICollection<V>, new()
    {
        private T _collection;


        public CollectionWrapper()
        {
            _collection = new T();    
        }

        public int Count
        {
            get { return _collection.Count; }
        }

        public T All
        {
            get { return _collection; }
        }
    }
}