﻿using System;
using System.Collections.Generic;

namespace ClassroomA
{
    public class FamilyRelation<T> where T : Animal
    {
        #region Instance fields
        private T _self;
        private T _father;
        private T _mother;
        private List<T> _children;
        #endregion

        #region Constructors
        public FamilyRelation(T self)
        {
            _self = self;
            _father = null;
            _mother = null;
            _children = new List<T>();
        }

        public FamilyRelation(
            T self,
            T father,
            T mother)
        {
            _self = self;
            _father = father;
            _mother = mother;
            _children = new List<T>();
        }
        #endregion

        #region Properties
        public T Self
        {
            get { return _self; }
        }

        public T Father
        {
            get { return _father; }
        }

        public T Mother
        {
            get { return _mother; }
        }

        public List<T> Children
        {
            get { return _children; }
        }
        #endregion

        #region Methods
        public void AddChild(T child)
        {
            _children.Add(child);
        }

        public void PrintNamesOfParents()
        {
            Console.WriteLine($"Parents: {_father.Name} and {_mother.Name}");
        }
        #endregion
    }
}

