﻿using System;
using System.Collections.Generic;

namespace ClassroomA
{
    public class FamilyRelationDog
    {
        #region Instance fields
        private Dog _self;
        private Dog _father;
        private Dog _mother;
        private List<Dog> _children;
        #endregion

        #region Constructor
        public FamilyRelationDog(Dog self)
        {
            _self = self;
            _father = null;
            _mother = null;
            _children = new List<Dog>();
        }

        public FamilyRelationDog(
            Dog self,
            Dog father,
            Dog mother)
        {
            _self = self;
            _father = father;
            _mother = mother;
            _children = new List<Dog>();
        }
        #endregion

        #region Properties
        public Dog Self
        {
            get { return _self; }
        }

        public Dog Father
        {
            get { return _father; }
        }

        public Dog Mother
        {
            get { return _mother; }
        }

        public List<Dog> Children
        {
            get { return _children; }
        }
        #endregion

        #region Methods
        public void AddChild(Dog child)
        {
            _children.Add(child);
        }

        public void PrintNamesOfParents()
        {
            Console.WriteLine($"Parents: {_father.Name} and {_mother.Name}");
        }
        #endregion
    }
}