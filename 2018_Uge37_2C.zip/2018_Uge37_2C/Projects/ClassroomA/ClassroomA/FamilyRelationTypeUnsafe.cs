﻿using System.Collections;

namespace ClassroomA
{
    public class FamilyRelationTypeUnsafe
    {
        #region Instance fields
        private object _self;
        private object _father;
        private object _mother;
        private ArrayList _children;
        #endregion

        #region Constructors
        public FamilyRelationTypeUnsafe(object self)
        {
            _self = self;
            _father = null;
            _mother = null;
            _children = new ArrayList();
        }

        public FamilyRelationTypeUnsafe(
            object self,
            object father,
            object mother)
        {
            _self = self;
            _father = father;
            _mother = mother;
            _children = new ArrayList();
        }
        #endregion

        #region Properties
        public object Self
        {
            get { return _self; }
        }

        public object Father
        {
            get { return _father; }
        }

        public object Mother
        {
            get { return _mother; }
        }

        public ArrayList Children
        {
            get { return _children; }
        }
        #endregion

        #region Methods
        public void AddChild(object child)
        {
            _children.Add(child);
        }

        public void PrintNamesOfParents()
        {
            // Console.WriteLine($"Parents: {_father.Name} and {_mother.Name}");
        } 
        #endregion
    }
}