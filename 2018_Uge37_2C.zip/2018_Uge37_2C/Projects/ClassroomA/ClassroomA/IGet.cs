﻿namespace ClassroomA
{
    public interface IGet<out T>
    {
        T Get();
    }
}