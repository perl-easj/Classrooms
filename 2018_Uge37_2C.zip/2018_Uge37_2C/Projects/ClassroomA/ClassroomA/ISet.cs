﻿namespace ClassroomA
{
    public interface ISet<in T>
    {
        void Set(T t);
    }
}