﻿namespace ClassroomA
{
    public class Functions
    {
        public static int Multiplier(int x, int y)
        {
            return x * y;
        }

        public static bool SmallerThan(int x, int y)
        {
            return x < y;
        }
    }
}