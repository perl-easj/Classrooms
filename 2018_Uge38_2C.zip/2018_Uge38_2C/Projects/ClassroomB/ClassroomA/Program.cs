﻿using System;
using System.Collections.Generic;

// ReSharper disable UnusedParameter.Local


namespace ClassroomA
{
    class Program
    {
        private static Random _generator = new Random();

        static void Main(string[] args)
        {
            LinkedList<int> linkedNumbers = new LinkedList<int>();
            Stack<int> numberStack = new Stack<int>();
            Queue<int> numberQueue = new Queue<int>();
            HashSet<int> numberSetA = new HashSet<int>();
            HashSet<int> numberSetB = new HashSet<int>();


            linkedNumbers.AddFirst(88);
            numberStack.Push(12);
            numberQueue.Enqueue(23);
            numberSetA.UnionWith(numberSetB);

            linkedNumbers.Find(34);
            int popped = numberStack.Pop();
            int deQueued = numberQueue.Dequeue();
            bool doesContain = numberSetA.Contains(56);

            //#region Setup
            //const int noOfNumbers = 10000;
            //const int noOfLinearSearches = 1000;
            //const int noOfBinarySearches = 1000000;

            //List<int> numbers = new List<int>();
            //for (int i = 0; i < noOfNumbers; i++)
            //{
            //    numbers.Add(_generator.Next(Int32.MaxValue));
            //}
            //#endregion

            //#region Lineær søgning
            //long runTimeLinear = TimedTester.MeasureRunTimeLoop(noOfLinearSearches, () =>
            //    {
            //        int valueToLookFor = _generator.Next(Int32.MaxValue);
            //        bool found = false;
            //        for (int index = 0; index < numbers.Count && !found; index++)
            //        {
            //            found = (numbers[index] == valueToLookFor);
            //        }
            //    }
            //);
            //Console.WriteLine($"Lineær søgning tog {(runTimeLinear * 1000) / noOfLinearSearches} mikro-sekunder for {noOfNumbers} elementer");
            //#endregion

            //#region Sortering
            //long runTimeSort = TimedTester.MeasureRunTimeLoop(1, () =>
            //    {
            //        numbers.Sort();
            //    }
            //);
            //Console.WriteLine($"Sortering tog {runTimeSort * 1000} mikro-sekunder for {noOfNumbers} elementer");
            //#endregion

            //#region Binær søgning
            //long runTimeBinary = TimedTester.MeasureRunTimeLoop(noOfBinarySearches, () =>
            //    {
            //        int valueToLookFor = _generator.Next(Int32.MaxValue);
            //        int index = numbers.BinarySearch(valueToLookFor);
            //    }
            //);
            //Console.WriteLine($"Binær søgning tog {(runTimeBinary * 1000000) / noOfBinarySearches} nano-sekunder for {noOfNumbers} elementer");
            //#endregion

            #region Kald af rekursive metoder
            //PrintHello(10);

            //Console.WriteLine($"8! = {Factorial(8)}");

            //int noOfdisks = 4;
            //Console.WriteLine($"Towers of Hanoi for {noOfdisks} disks:");
            //TowersOfHanoi("A", "B", "C", 4);
            //Console.WriteLine();

            for (int disks = 1; disks <= 30; disks++)
            {
                int moves = TowersOfHanoi("A", "B", "C", disks, true);
                Console.WriteLine($"{disks} discs took {moves} moves");
            }

            //Test(10000000);

            #endregion

            Console.WriteLine("Done - press any key to shut down the app");
            Console.ReadKey();
        }

        #region Definition af rekursive metoder
        public static void PrintHello()
        {
            Console.WriteLine("Hello");
            PrintHello();
        }

        public static void PrintHello(int numberOfCallsLeft)
        {
            if (numberOfCallsLeft > 0)
            {
                Console.WriteLine("Hello");
                PrintHello(numberOfCallsLeft - 1);
            }
        }

        public static int Factorial(int n)
        {
            return (n <= 1) ? 1 : (n * Factorial(n - 1));
        }

        public static int TowersOfHanoi(string pegA, string pegB, string pegC, int n, bool silent = false)
        {
            if (n > 0)
            {
                int a = TowersOfHanoi(pegA, pegC, pegB, n - 1, silent);
                if (!silent) { Console.WriteLine("Move disk " + n + ": " + pegA + "->" + pegC); }
                int b = TowersOfHanoi(pegB, pegA, pegC, n - 1, silent);
                return a + b + 1;
            }

            return 0;
        }

        private static void Test(int v)
        {
            if (v > 0)
            {
                Test(v - 1);
            }
            else
            {
                return;
            }
        }
        #endregion
    }
}
