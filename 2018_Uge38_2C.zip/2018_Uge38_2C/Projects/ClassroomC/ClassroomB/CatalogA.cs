﻿using System;
using System.Collections.Generic;

namespace ClassroomB
{
    public class Catalog<T> where T : new()
    {
        private List<T> _objects;

        public void Add(T obj)
        {
            _objects.Add(obj);
        }

        public void AddBlank()
        {
            _objects.Add(new T());
        }
    }
}