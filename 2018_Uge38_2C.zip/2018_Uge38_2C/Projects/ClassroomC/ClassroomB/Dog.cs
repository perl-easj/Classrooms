﻿namespace ClassroomB
{
    public class Dog
    {
        private string _name;

        public Dog(string name)
        {
            _name = name;
        }

        public Dog()
        {
            _name = "King";
        }
    }
}