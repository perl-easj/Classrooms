﻿using System;
using System.Threading.Tasks;

namespace ClassroomB
{
    public class PrimeCalcA
    {
        #region FindNoOfPrimes - standard implementation
        //public int FindNoOfPrimes(int upper)
        //{
        //    int noOfPrimes = FindNOPII(1, upper);
        //    return noOfPrimes;
        //}
        #endregion

        #region FindNoOfPrimes - implementation using Tasks
        public int FindNoOfPrimes(int upper)
        {
            int nopiiA = 0;
            int nopiiB = 0;
            int nopiiC = 0;
            int nopiiD = 0;

            int p25 = upper / 4;
            int p50 = upper / 2;
            int p75 = (upper * 3) / 4;

            Task taskA = new Task(() => { nopiiA = FindNOPII(1, p25); });
            Task taskB = new Task(() => { nopiiB = FindNOPII(p25 + 1, p50); });
            Task taskC = new Task(() => { nopiiC = FindNOPII(p50 + 1, p75); });
            Task taskD = new Task(() => { nopiiD = FindNOPII(p75 + 1, upper); });
            //Task<int> taskA = new Task<int>(() => FindNOPII(1, p25));
            //Task<int> taskB = new Task<int>(() => FindNOPII(p25 + 1, p50));
            //Task<int> taskC = new Task<int>(() => FindNOPII(p50 + 1, p75));
            //Task<int> taskD = new Task<int>(() => FindNOPII(p75 + 1, upper));

            taskA.Start();
            taskB.Start();
            taskC.Start();
            taskD.Start();

            //int nopiiA = await taskA;
            //int nopiiB = await taskB;
            //int nopiiC = await taskC;
            //int nopiiD = await taskD;

            Task.WaitAll(taskA, taskB, taskC, taskD);

            return nopiiA + nopiiB + nopiiC + nopiiD;
        }
        #endregion

        private int FindNOPII(int lower, int upper)
        {
            int noOfPrimes = 0;
            for (int i = lower; i < upper; i++)
            {
                if (IsPrime(i))
                {
                    noOfPrimes++;
                }
            }

            return noOfPrimes;
        }

        private static bool IsPrime(int number)
        {
            if (number < 4) { return true; }

            int limit = Convert.ToInt32(Math.Sqrt(number));
            bool isPrime = true;

            for (int i = 2; i <= limit && isPrime; i++)
            {
                isPrime = number % i != 0;
            }

            return isPrime;
        }

    }
}