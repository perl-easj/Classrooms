﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace ClassroomB
{
    class Program
    {
        private static Random _generator = new Random();

        static async Task Main(string[] args)
        {
            Catalog<Dog> dogCatalog = new Catalog<Dog>();


            TestPrimeCalc();
            // await TestPrimeCalc();

            //TaskExamples te = new TaskExamples();
            //te.CallCallBigJob();

            Console.WriteLine("Done - press any key to shut down the app");
            Console.ReadKey();


        }

        private void Test()
        {
            int a = 12;
            Console.WriteLine(SquareOf(a));
        }

        private int SquareOf6()
        {
            return 6 * 6;
        }

        private int SquareOf9()
        {
            return 9 * 9;
        }

        private int SquareOf(int x)
        {
            return  x * x;
        }

        private static void TestAverageCalc()
        {
            List<int> lotsOfNumbers = new List<int>();
            const int noOfNumbers = 10000000;
            AverageCalculator avCalc = new AverageCalculator();

            Console.WriteLine("Generating random numbers...");
            for (int i = 0; i < noOfNumbers; i++)
            {
                lotsOfNumbers.Add(_generator.Next(Int32.MaxValue));
            }
            Console.WriteLine("Done, starting calculation...");


            CancellationTokenSource tokenSource = new CancellationTokenSource();
            CancellationToken token = tokenSource.Token;

            Task taskUI = new Task(() =>
            {
                Console.WriteLine("Type c for cancel");
                string userInput = "";
                while (userInput != "c")
                {
                    userInput = Console.ReadKey(true).KeyChar.ToString();
                    if (userInput == "c")
                    {
                        tokenSource.Cancel();
                    }
                }
            });
            taskUI.Start();

            long average = avCalc.AverageAsTask(lotsOfNumbers, token);
            Console.WriteLine($"Average of {noOfNumbers} numbers is {average}");
        }

        private static async Task TestPrimeCalc()
        {
            int upperLimit = 1000000;
            Stopwatch watch = new Stopwatch();
            PrimeCalcB calcB = new PrimeCalcB();

            watch.Restart();
            calcB.FindPrimes(upperLimit);
            watch.Stop();

            // Console.WriteLine($"Found {noOfPrimes} primes in [2; {upperLimit}]");
            Console.WriteLine($"Took {watch.ElapsedMilliseconds} milliSecs");
        }
    }
}
