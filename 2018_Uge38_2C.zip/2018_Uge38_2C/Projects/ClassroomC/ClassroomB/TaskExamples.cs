﻿using System;
using System.Threading.Tasks;

namespace ClassroomB
{
    public class TaskExamples
    {
        private TextBlock _aTextBlock;

        public async void CallBigJobGUI()
        {
            Task<int> taskCallBigJob = CallBigJob();

            // Giv kontrol tilbage til GUI-loop
            await taskCallBigJob;

            _aTextBlock.Text = $"Result is {taskCallBigJob.Result}";
        }

        public int CallCallBigJob()
        {
            Task<int> taskCallBigJob = CallBigJob();

            // Et eller andet sted skal vi jo vente...
            taskCallBigJob.Wait(); 

            return taskCallBigJob.Result;
        }

        public async Task<int> CallBigJob()
        {
            Task<int> taskBigJob = BigJob();
            await taskBigJob;
            return taskBigJob.Result;
        }

        public async Task<int> BigJob()
        {
            Task<int> aTask = new Task<int>(BigJobPartA);
            Task<int> bTask = new Task<int>(BigJobPartB);
            Task<int> cTask = new Task<int>(BigJobPartC);

            aTask.Start();
            bTask.Start();
            cTask.Start();

            await aTask;
            await bTask;
            await cTask;

            int finalResult = aTask.Result + bTask.Result + cTask.Result;
            return finalResult;
        }

        public int BigJobPartA()
        {
            return 0;
        }

        public int BigJobPartB()
        {
            return 0;
        }

        public int BigJobPartC()
        {
            return 0;
        }
    }

    internal class TextBlock
    {
        public string Text { get; set; }
    }
}